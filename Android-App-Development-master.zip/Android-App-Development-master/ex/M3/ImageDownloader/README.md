This folder contains the following material design-based
implementations of an ImageDownloader app using Android Studio:

IS -- This folder contains an ImageDownloader app that uses an
intent service.

SS -- This folder contains an ImageDownloader app that uses a started
service.




