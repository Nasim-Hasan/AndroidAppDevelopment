This repository contains examples for the second MOOC on "Android App
Components: Intents, Activities, and Broadcast Receivers" in the
Android App Development MOOC Specialization for the Coursera platform.
