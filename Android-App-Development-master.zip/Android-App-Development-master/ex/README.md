This repository contains examples for the MOOCs in the Android App
Development MOOC Specialization for the Coursera platform.
